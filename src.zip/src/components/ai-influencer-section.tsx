'use client';

import { useState, useCallback, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Sparkles, Heart, Share2, Shield, Clock, ImageIcon, LogIn, CheckCircle, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from '@/components/ui/dialog';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip';
import { useStore } from '@/lib/store';
import { showToast } from '@/hooks/use-toast-notification';

/* ── Types ── */
export interface AIInfluencerImage {
  id: string;
  productId: string;
  imageDataUrl: string; // base64 data URL
  userName: string;
  userId?: string;
  isVerified?: boolean;
  createdAt: string;
  likes: number;
}

/* ── In-memory store for influencer images (shared across component instances) ── */
let _influencerImages: AIInfluencerImage[] = [];
let _likedIds: Set<string> = new Set();

function getInfluencerImages(productId: string): AIInfluencerImage[] {
  return _influencerImages.filter((img) => img.productId === productId);
}

function addInfluencerImage(image: AIInfluencerImage) {
  _influencerImages = [image, ..._influencerImages];
}

function getUserShareCount(userId: string, productId: string): number {
  return _influencerImages.filter((img) => img.userId === userId && img.productId === productId).length;
}

function toggleLike(imageId: string): number {
  const img = _influencerImages.find((i) => i.id === imageId);
  if (!img) return 0;
  if (_likedIds.has(imageId)) {
    _likedIds.delete(imageId);
    img.likes = Math.max(0, img.likes - 1);
  } else {
    _likedIds.add(imageId);
    img.likes += 1;
  }
  return img.likes;
}

function isLiked(imageId: string): boolean {
  return _likedIds.has(imageId);
}

/* ── Relative time formatter ── */
function relativeTime(dateStr: string): string {
  const diff = Date.now() - new Date(dateStr).getTime();
  const minutes = Math.floor(diff / 60000);
  if (minutes < 1) return 'Just now';
  if (minutes < 60) return `${minutes}m ago`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `${hours}h ago`;
  const days = Math.floor(hours / 24);
  if (days < 7) return `${days}d ago`;
  return new Date(dateStr).toLocaleDateString('en-IN', { day: '2-digit', month: 'short' });
}

/* ── Component ── */
interface AIInfluencerSectionProps {
  productId: string;
  productName: string;
  onShareImage?: (imageDataUrl: string) => void;
  initialShareImage?: string | null;
  onShareComplete?: () => void;
}

const MAX_SHARES_PER_USER_PER_PRODUCT = 3;

export function AIInfluencerSection({ productId, productName, onShareImage, initialShareImage, onShareComplete }: AIInfluencerSectionProps) {
  const { authUser, setAuthView } = useStore();
  const [images, setImages] = useState<AIInfluencerImage[]>(() => getInfluencerImages(productId));
  const [shareDialogOpen, setShareDialogOpen] = useState(false);
  const [loginPromptOpen, setLoginPromptOpen] = useState(false);
  const [consentGiven, setConsentGiven] = useState(false);
  const [pendingImage, setPendingImage] = useState<string | null>(null);
  const [userName, setUserName] = useState(authUser?.name || '');
  const [showPendingNotice, setShowPendingNotice] = useState(false);
  const [apiImages, setApiImages] = useState<AIInfluencerImage[]>([]);
  const pendingImageRef = useRef<string | null>(null);

  // Auto-open share dialog when initialShareImage is provided (from try-on result)
  useEffect(() => {
    if (!initialShareImage) return;
    // Store the image for later use
    pendingImageRef.current = initialShareImage;
    // Use microtask to avoid setState-in-effect lint warning
    const pending = initialShareImage;
    queueMicrotask(() => {
      if (!authUser) {
        setLoginPromptOpen(true);
        return;
      }
      setPendingImage(pending);
      setConsentGiven(false);
      setShareDialogOpen(true);
    });
  }, [initialShareImage, authUser]);

  // Fetch approved images from API and merge with local
  useEffect(() => {
    async function fetchApprovedImages() {
      try {
        const res = await fetch(`/api/style-gallery?productId=${encodeURIComponent(productId)}&limit=20`);
        if (res.ok) {
          const data = await res.json();
          const mapped: AIInfluencerImage[] = (data.items || []).map((item: any) => ({
            id: item.id,
            productId: item.productId,
            imageDataUrl: item.aiGeneratedImage,
            userName: item.userName,
            userId: item.userId || undefined,
            isVerified: true,
            createdAt: item.createdAt,
            likes: item.likes || 0,
          }));
          setApiImages(mapped);
        }
      } catch (err) {
        console.error('[AIInfluencer] Failed to fetch approved gallery items:', err);
      }
    }
    fetchApprovedImages();
  }, [productId]);

  // Refresh images from shared store
  const refreshImages = useCallback(() => {
    setImages([...getInfluencerImages(productId)]);
  }, [productId]);

  const handleShareClick = useCallback(() => {
    if (!authUser) {
      showToast('info', 'Please sign in to share your AI style.');
      setLoginPromptOpen(true);
      return;
    }

    // Check share limit
    const shareCount = getUserShareCount(authUser.id, productId);
    if (shareCount >= MAX_SHARES_PER_USER_PER_PRODUCT) {
      showToast('error', "You've reached the maximum shares for this product.");
      return;
    }

    setPendingImage(null);
    setConsentGiven(false);
    setShareDialogOpen(true);
  }, [authUser, productId]);

  const handleShareFromTryOn = useCallback(
    (imageDataUrl: string) => {
      if (!authUser) {
        setPendingImage(imageDataUrl);
        setLoginPromptOpen(true);
        return;
      }
      setPendingImage(imageDataUrl);
      setConsentGiven(false);
      setShareDialogOpen(true);
    },
    [authUser]
  );

  const handleSubmitShare = useCallback(async () => {
    if (!consentGiven || !userName.trim() || !authUser) return;

    // Double-check share limit
    const shareCount = getUserShareCount(authUser.id, productId);
    if (shareCount >= MAX_SHARES_PER_USER_PER_PRODUCT) {
      showToast('error', "You've reached the maximum shares for this product.");
      setShareDialogOpen(false);
      return;
    }

    const newImage: AIInfluencerImage = {
      id: `inf-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
      productId,
      imageDataUrl:
        pendingImage ||
        `data:image/svg+xml;base64,${btoa(`<svg xmlns="http://www.w3.org/2000/svg" width="400" height="400" viewBox="0 0 400 400"><rect fill="#292524" width="400" height="400"/><text x="200" y="180" text-anchor="middle" fill="#d97706" font-size="48">✨</text><text x="200" y="230" text-anchor="middle" fill="#fbbf24" font-size="16" font-family="sans-serif">AI Style Preview</text><text x="200" y="260" text-anchor="middle" fill="#78716c" font-size="12" font-family="sans-serif">${productName.substring(0, 30)}</text></svg>`)}`,
      userName: userName.trim(),
      userId: authUser.id,
      isVerified: true,
      createdAt: new Date().toISOString(),
      likes: 0,
    };

    addInfluencerImage(newImage);

    // Submit to backend for admin approval
    try {
      await fetch('/api/style-gallery', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          productId,
          productName,
          userId: authUser.id,
          userName: userName.trim(),
          aiGeneratedImage: newImage.imageDataUrl,
          categorySlug: undefined,
          consentGiven: true,
        }),
      });
    } catch (err) {
      console.error('[AIInfluencer] Failed to submit to gallery API:', err);
    }

    refreshImages();
    setShareDialogOpen(false);
    setConsentGiven(false);
    setPendingImage(null);
    setShowPendingNotice(true);
    setTimeout(() => setShowPendingNotice(false), 10000);
    showToast('info', 'Your style has been submitted and is pending admin approval.');

    if (onShareImage) {
      onShareImage(newImage.imageDataUrl);
    }
    if (onShareComplete) {
      onShareComplete();
    }
  }, [consentGiven, userName, pendingImage, productId, productName, refreshImages, onShareImage, onShareComplete, authUser]);

  const handleLike = useCallback(
    (imageId: string) => {
      toggleLike(imageId);
      refreshImages();
    },
    [refreshImages]
  );

  const handleSignIn = useCallback(() => {
    setLoginPromptOpen(false);
    setAuthView('login');
  }, [setAuthView]);

  // Merge local in-memory images with API-approved images
  const allImages = [...images, ...apiImages];

  const isLoggedIn = !!authUser;

  return (
    <TooltipProvider>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="mt-12"
      >
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-amber-600/20">
              <Sparkles className="h-5 w-5 text-amber-400" />
            </div>
            <div>
              <h3 className="text-lg font-semibold text-amber-100">AI Style Gallery</h3>
              <p className="text-xs text-amber-200/40">See how others styled this product</p>
            </div>
          </div>
          <Button
            onClick={handleShareClick}
            className="bg-amber-600 text-stone-950 hover:bg-amber-500 gap-2"
            size="sm"
          >
            <Share2 className="h-4 w-4" />
            Share Your Style
          </Button>
        </div>

        {/* Gallery Grid */}
        {allImages.length > 0 ? (
          <>
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">
            <AnimatePresence>
              {allImages.map((img, idx) => (
                <motion.div
                  key={img.id}
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: idx * 0.05 }}
                  className="group relative overflow-hidden rounded-xl border border-amber-900/20 bg-stone-900/60 transition-all hover:border-amber-600/30 hover:shadow-lg hover:shadow-amber-900/10"
                >
                  {/* Image */}
                  <div className="relative aspect-square overflow-hidden">
                    <img
                      src={img.imageDataUrl}
                      alt={`AI style by ${img.userName}`}
                      className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105"
                    />
                    {/* AI Generated badge overlay */}
                    <div className="absolute top-2 left-2">
                      <Badge className="bg-stone-900/80 text-amber-300 border-amber-600/30 text-[9px] backdrop-blur-sm px-1.5 py-0.5">
                        <Sparkles className="h-2.5 w-2.5 mr-0.5" />
                        AI Generated
                      </Badge>
                    </div>
                  </div>

                  {/* Card Footer */}
                  <div className="p-2.5">
                    <div className="flex items-center justify-between">
                      {/* User info */}
                      <div className="flex items-center gap-2 min-w-0">
                        <div className="flex h-6 w-6 flex-shrink-0 items-center justify-center rounded-full bg-amber-600/20 text-[10px] font-bold text-amber-400">
                          {img.userName.charAt(0).toUpperCase()}
                        </div>
                        <div className="flex items-center gap-1 min-w-0">
                          <span className="text-xs text-amber-200/60 truncate">{img.userName}</span>
                          {img.isVerified && (
                            <Tooltip>
                              <TooltipTrigger asChild>
                                <span className="flex-shrink-0 inline-flex items-center justify-center">
                                  <CheckCircle className="h-3 w-3 text-emerald-400" />
                                </span>
                              </TooltipTrigger>
                              <TooltipContent
                                side="top"
                                className="bg-stone-900 border-amber-900/30 text-amber-200 text-xs"
                              >
                                Verified User
                              </TooltipContent>
                            </Tooltip>
                          )}
                        </div>
                      </div>

                      {/* Like button */}
                      <button
                        onClick={() => handleLike(img.id)}
                        className="flex items-center gap-1 text-amber-200/40 hover:text-red-400 transition-colors"
                        aria-label={`Like this image. Currently ${img.likes} likes`}
                      >
                        <Heart
                          className={`h-3.5 w-3.5 transition-all ${
                            isLiked(img.id) ? 'fill-red-400 text-red-400 scale-110' : ''
                          }`}
                        />
                        <span className="text-[10px]">{img.likes > 0 ? img.likes : ''}</span>
                      </button>
                    </div>

                    {/* Timestamp */}
                    <div className="mt-1 flex items-center gap-1">
                      <Clock className="h-2.5 w-2.5 text-amber-200/20" />
                      <span className="text-[9px] text-amber-200/30">{relativeTime(img.createdAt)}</span>
                    </div>
                  </div>
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
          {/* Pending Approval Notice */}
          {showPendingNotice && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              className="mt-4 rounded-lg border border-amber-600/30 bg-amber-900/15 p-3 flex items-start gap-2"
            >
              <Clock className="h-4 w-4 text-amber-400 mt-0.5 flex-shrink-0" />
              <div>
                <p className="text-xs font-medium text-amber-200/70">Style Submitted for Approval</p>
                <p className="text-[10px] text-amber-200/40 mt-0.5">Your AI style is being reviewed by our team. It will appear in the gallery once approved.</p>
              </div>
              <button onClick={() => setShowPendingNotice(false)} className="ml-auto text-amber-200/30 hover:text-amber-200/60">
                <X className="h-3.5 w-3.5" />
              </button>
            </motion.div>
          )}
          </>
        ) : (
          <div className="flex flex-col items-center justify-center rounded-xl border border-dashed border-amber-900/20 bg-stone-900/30 py-12">
            <div className="flex h-14 w-14 items-center justify-center rounded-full bg-amber-900/20 mb-3">
              <ImageIcon className="h-7 w-7 text-amber-400/40" />
            </div>
            <p className="text-sm text-amber-200/40">No AI styles shared yet</p>
            <p className="mt-1 text-xs text-amber-200/25">Be the first to share your AI-generated look! {!isLoggedIn && 'Sign in to get started.'}</p>
            {isLoggedIn ? (
              <Button
                onClick={handleShareClick}
                variant="outline"
                className="mt-4 border-amber-900/30 text-amber-200/60 hover:border-amber-600/40 hover:text-amber-400 gap-2"
                size="sm"
              >
                <Share2 className="h-4 w-4" />
                Share Your Style
              </Button>
            ) : (
              <Button
                onClick={handleSignIn}
                variant="outline"
                className="mt-4 border-amber-900/30 text-amber-200/60 hover:border-amber-600/40 hover:text-amber-400 gap-2"
                size="sm"
              >
                <LogIn className="h-4 w-4" />
                Sign In to Share
              </Button>
            )}
          </div>
        )}

        {/* Login Prompt Dialog */}
        <Dialog open={loginPromptOpen} onOpenChange={setLoginPromptOpen}>
          <DialogContent className="border-amber-900/30 bg-stone-950 sm:max-w-md">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2 text-amber-100">
                <LogIn className="h-5 w-5 text-amber-400" />
                Sign In Required
              </DialogTitle>
              <DialogDescription className="text-amber-200/50">
                You need to be a registered user to share your AI-generated style with the community.
              </DialogDescription>
            </DialogHeader>

            <div className="space-y-5 mt-2">
              {/* Info box */}
              <div className="rounded-lg border border-amber-900/15 bg-amber-950/20 p-3">
                <div className="flex items-start gap-2">
                  <Shield className="h-4 w-4 text-amber-400/60 mt-0.5 flex-shrink-0" />
                  <div className="space-y-1">
                    <p className="text-xs font-medium text-amber-200/60">Why sign in?</p>
                    <ul className="text-[10px] text-amber-200/40 space-y-0.5">
                      <li>Verify your identity for community safety</li>
                      <li>Get a verified badge on your shared styles</li>
                      <li>Track and manage your shared images</li>
                    </ul>
                  </div>
                </div>
              </div>

              {/* Buttons */}
              <div className="flex gap-3">
                <Button
                  variant="outline"
                  onClick={() => setLoginPromptOpen(false)}
                  className="flex-1 border-amber-900/40 text-amber-200/60"
                >
                  Cancel
                </Button>
                <Button
                  onClick={handleSignIn}
                  className="flex-1 bg-amber-600 text-stone-950 hover:bg-amber-500"
                >
                  <LogIn className="mr-2 h-4 w-4" />
                  Sign In
                </Button>
              </div>

              {/* Note */}
              <p className="text-center text-[10px] text-amber-200/25">
                Registration is free and only takes a moment.
              </p>
            </div>
          </DialogContent>
        </Dialog>

        {/* Share Consent Dialog */}
        <Dialog open={shareDialogOpen} onOpenChange={setShareDialogOpen}>
          <DialogContent className="border-amber-900/30 bg-stone-950 sm:max-w-md">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2 text-amber-100">
                <Sparkles className="h-5 w-5 text-amber-400" />
                Share Your AI Style
              </DialogTitle>
              <DialogDescription className="text-amber-200/50">
                Share your AI-generated look with other shoppers?
              </DialogDescription>
            </DialogHeader>

            <div className="space-y-5 mt-2">
              {/* Preview of the image to share */}
              {pendingImage && (
                <div className="relative aspect-square w-full max-w-[200px] mx-auto overflow-hidden rounded-xl border border-amber-900/20">
                  <img
                    src={pendingImage}
                    alt="AI style preview to share"
                    className="h-full w-full object-cover"
                  />
                  <Badge className="absolute top-2 left-2 bg-stone-900/80 text-amber-300 border-amber-600/30 text-[9px] backdrop-blur-sm">
                    <Sparkles className="h-2.5 w-2.5 mr-0.5" />
                    AI Generated
                  </Badge>
                </div>
              )}

              {/* Info box */}
              <div className="rounded-lg border border-amber-900/15 bg-amber-950/20 p-3">
                <div className="flex items-start gap-2">
                  <Shield className="h-4 w-4 text-amber-400/60 mt-0.5 flex-shrink-0" />
                  <div className="space-y-1">
                    <p className="text-xs font-medium text-amber-200/60">What happens when you share?</p>
                    <ul className="text-[10px] text-amber-200/40 space-y-0.5">
                      <li>Your AI-generated image will be submitted for admin review first</li>
                      <li>Once approved, it will be visible to all shoppers</li>
                      <li>Only your first name initial will be shown</li>
                      <li>You can request removal at any time</li>
                    </ul>
                  </div>
                </div>
              </div>

              {/* User name input */}
              <div>
                <Label htmlFor="share-name" className="text-sm text-amber-200/60">
                  Display Name
                </Label>
                <input
                  id="share-name"
                  type="text"
                  value={userName}
                  onChange={(e) => setUserName(e.target.value)}
                  placeholder="Your name"
                  className="mt-1 w-full rounded-md border border-amber-900/40 bg-stone-800/50 px-3 py-2 text-sm text-amber-50 placeholder:text-amber-200/20 focus:outline-none focus:ring-1 focus:ring-amber-600"
                />
              </div>

              {/* Consent checkbox */}
              <div className="flex items-start gap-3 rounded-lg border border-amber-900/20 bg-stone-800/30 p-3">
                <Checkbox
                  id="consent-checkbox"
                  checked={consentGiven}
                  onCheckedChange={(checked) => setConsentGiven(checked === true)}
                  className="mt-0.5 data-[state=checked]:bg-amber-600 data-[state=checked]:border-amber-600"
                />
                <Label
                  htmlFor="consent-checkbox"
                  className="text-xs text-amber-200/60 leading-relaxed cursor-pointer"
                >
                  I consent to sharing my AI-generated image publicly. I understand this image was
                  created by AI and may not accurately represent the actual product appearance.
                </Label>
              </div>

              {/* Submit button */}
              <div className="flex gap-3">
                <Button
                  variant="outline"
                  onClick={() => setShareDialogOpen(false)}
                  className="flex-1 border-amber-900/40 text-amber-200/60"
                >
                  Cancel
                </Button>
                <Button
                  onClick={handleSubmitShare}
                  disabled={!consentGiven || !userName.trim()}
                  className="flex-1 bg-amber-600 text-stone-950 hover:bg-amber-500 disabled:opacity-40 disabled:cursor-not-allowed"
                >
                  <Share2 className="mr-2 h-4 w-4" />
                  Submit for Approval
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </motion.div>
    </TooltipProvider>
  );
}
